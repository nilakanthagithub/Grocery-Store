
export const routeList = [
  { key: 'home', value: 'Home' },
  { key: 'branded', value: 'Branded Foods' },
  { key: 'household', value: 'Households' },
  { key: 'fruit', value: 'Fruits & Vegitables' },
  { key: 'kitchen', value: 'Kitchen' },
  { key: 'beverage', value: 'Beverages' },
  { key: 'pet', value: 'Pet Foods' },
  { key: 'frozen', value: 'Frozen Foods' },
  { key: 'bread', value: 'Bread & Bakery' },
  { key: 'event', value: 'Events' },
  { key: 'about', value: 'About Us' },
  { key: 'service', value: 'Services' },
  { key: 'login', value: 'Sign In' },
  { key: 'register', value: 'Sign Up' },
  { key: 'contact', value: 'Contact Us' }
];