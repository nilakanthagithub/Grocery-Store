import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import { routeList } from './route-list';

@Component({
  selector: 'app-fixed-nav',
  templateUrl: './fixed-nav.component.html',
  styleUrls: ['./fixed-nav.component.css']
})
export class FixedNavComponent implements OnInit {

  //breadcrumbList: Array<any> = [];
  routerUrl: string;
  isHome: boolean;
  routeList = routeList;
  curRoute: string;

  constructor(private _router: Router) { }

  ngOnInit() {
    this.listenRouting();
  }

  listenRouting() {
    this._router.events.subscribe((router: any) => {
      this.routerUrl = router.urlAfterRedirects;
      this.isHome = (this.routerUrl =="/home") ? true : false;
      if(this.routerUrl){
        for(let i of this.routeList){
          if(i.key==this.routerUrl.substr(1)){
            this.curRoute=i.value;
            break;
          }
        }
      }
    });
  }

}
