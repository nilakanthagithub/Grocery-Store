import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-frozen',
  templateUrl: './frozen.component.html',
  styleUrls: ['./frozen.component.css']
})
export class FrozenComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
