import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-household',
  templateUrl: './household.component.html',
  styleUrls: ['./household.component.css']
})
export class HouseholdComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
