import { Component, OnInit } from '@angular/core';

import { product } from '../product-list';

@Component({
  selector: 'app-branded',
  templateUrl: './branded.component.html',
  styleUrls: ['./branded.component.css']
})
export class BrandedComponent implements OnInit {

  product = product;

  constructor() { }

  ngOnInit() {
  }

}
